
#diravon = paste ( dirtop, '/avon/', sep = '' )
#dir02 = paste ( diravon, '/O2/', sep = '' )

#O2_sol = read.csv ( paste ( dir02, 'O2_solubility.csv', sep = '' ), header = T)

#CalcCsat <- function ( Temp, pressure )
CalcCsat <- function ( input )
	{

	Temp = input[1]
	pressure = input[2]

	stopifnot(Temp >= 0 & Temp < 40 | is.na (Temp))
    stopifnot(pressure >= 90 & pressure < 108 | is.na (pressure))
    
	#Temp = 34.5
	#pressure = 100.5
	
	floorTemp = floor (Temp)
	floorpressure = floor (pressure)
	
	
	c_pressure = paste ( 'kPa', floorpressure, sep = '' )
	
	
	a1 = match ( floorTemp, O2_sol[ , c('Temp')] )
	b1 =  which ( names(O2_sol) == c_pressure)
	
	
	O2_mg1 = O2_sol[a1,b1]
	O2_mg2 = O2_sol[a1+1,b1]
	
	O2_mg =  (O2_mg2 -  O2_mg1) * (Temp - floorTemp) + O2_mg1
	
	O2_mg1 = O2_sol[a1,b1]
	O2_mg2 = O2_sol[a1,b1 + 1]

	# pressure - floorpressure will always be between 0 and 1
	# therefore this is a proportion
	pressure_adj = (O2_mg2 -  O2_mg1) * (pressure - floorpressure)
	
	O2_mg = O2_mg + pressure_adj
	
	return (O2_mg)
	}

#save (O2_sol, file = 'O2_sol.rda')


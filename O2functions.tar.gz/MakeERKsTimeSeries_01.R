
MakeERKsTimeSeriesDataSet <- function ( indata, inparams, which_return = 1, n_quality = 1 )
	{

	library (rovelli)
	stopifnot ( which_return %in%  c(1,2,3))

	#c_indata1 <- 'Ebble_CE1_2013_08_08'
	#c_inparams <- 'Ebble_CE1_2013_08_08_ER_Ks'
	#c_set <- 'for'

	data_new <- merge (indata, inparams, by = 'date1')
	data_new$date1 <- try (data_new$date1.x)

	indata$ER <- NA
	indata$Ks <- NA

	for ( i in 1:dim(inparams)[1] )
		{
		i_sub <- inparams[i,]
		indata$ER[indata$daynight1 == i_sub$daynight1] <- i_sub$ER
		indata$Ks[indata$daynight1 == i_sub$daynight1] <- i_sub$Ks
		}

	indata_sub <- indata[!is.na (indata$ER),]
	banana <- approxfun ( indata_sub$date, indata_sub$ER )
	banana_out <- banana (  indata$date )
	indata$ER <- banana_out


	indata_sub <- indata[!is.na (indata$Ks),]
	banana <- approxfun ( indata_sub$date, indata_sub$Ks )
	banana_out <- banana (  indata$date )
	indata$Ks <- banana_out

	first_notNA <- head (which (!is.na (banana_out)),1)
	last_notNA <- tail (which (!is.na (banana_out)),1)

	early_NA_ndx <- which (indata$date < indata$date[first_notNA])
	late_NA_ndx <- which (indata$date > indata$date[last_notNA])

	indata$ER[early_NA_ndx]  <- indata$ER[first_notNA]
	indata$Ks[early_NA_ndx]  <- indata$Ks[first_notNA]

	indata$ER[late_NA_ndx]  <- indata$ER[last_notNA]
	indata$Ks[late_NA_ndx]  <- indata$Ks[last_notNA]

	plot ( indata$date)
	plot ( indata$date, indata$DO )

	plot ( indata$date, indata$ER )
	plot ( indata$date, indata$Ks )


	if ( !is.null(indata$qualityFilter01))
		{
		indata <- indata[indata$qualityFilter01 >= n_quality,]
		}



	x <- indata [ c ('date','ER','Ks')]
	
	if (which_return == 2)
		{
		x$date1 <- as.Date ( x$date )
		}
	
	if (which_return == 1)
		{
		x <- indata
		}
	
	print (names (x))
	return (x)
	}


#x1 <- MakeERKsTimeSeriesDataSet ()







































MakeERKsTimeSeries <- function ( c_indata1, c_inparams, c_set = 'for', c_library = 'rovelli', which_return = 1, n_quality = 2 )
	{

	library (rovelli)
	stopifnot ( c_set %in%  c('for', 'mid', 'lag'))
	stopifnot ( which_return %in%  c(1,2,3))

	#c_indata1 <- 'Ebble_CE1_2013_08_08'
	#c_inparams <- 'Ebble_CE1_2013_08_08_ER_Ks'
	#c_set <- 'for'

	
	do.call ( library, list (c_library))

	do.call ( data, list (c_indata1))
	do.call ( data, list (c_inparams))

	indata <- get ( c_indata1 )
	inparams <- get ( paste (c_inparams, '_',  c_set, sep = ''))

	data_new <- merge (indata, inparams, by = 'date1')
	data_new$date1 <- try (data_new$date1.x)

	indata$ER <- NA
	indata$Ks <- NA

	for ( i in 1:dim(inparams)[1] )
		{
		i_sub <- inparams[i,]
		indata$ER[indata$daynight1 == i_sub$daynight1] <- i_sub$ER
		indata$Ks[indata$daynight1 == i_sub$daynight1] <- i_sub$Ks
		}

	indata_sub <- indata[!is.na (indata$ER),]
	banana <- approxfun ( indata_sub$date, indata_sub$ER )
	banana_out <- banana (  indata$date )
	indata$ER <- banana_out


	indata_sub <- indata[!is.na (indata$Ks),]
	banana <- approxfun ( indata_sub$date, indata_sub$Ks )
	banana_out <- banana (  indata$date )
	indata$Ks <- banana_out

	first_notNA <- head (which (!is.na (banana_out)),1)
	last_notNA <- tail (which (!is.na (banana_out)),1)

	early_NA_ndx <- which (indata$date < indata$date[first_notNA])
	late_NA_ndx <- which (indata$date > indata$date[last_notNA])

	indata$ER[early_NA_ndx]  <- indata$ER[first_notNA]
	indata$Ks[early_NA_ndx]  <- indata$Ks[first_notNA]

	indata$ER[late_NA_ndx]  <- indata$ER[last_notNA]
	indata$Ks[late_NA_ndx]  <- indata$Ks[last_notNA]

	plot ( indata$date)
	plot ( indata$date, indata$DO )

	plot ( indata$date, indata$ER )
	plot ( indata$date, indata$Ks )


	if ( !is.null(indata$qualityFilter))
	{
	indata <- indata[indata$qualityFilter > n_quality,]
	}



	x <- indata [ c ('date','ER','Ks')]
	
	if (which_return == 2)
		{
		x$date1 <- as.Date ( x$date )
		}
	
	if (which_return == 1)
		{
		x <- indata
		}
	
	print (names (x))
	return (x)
	}


#x1 <- MakeERKsTimeSeries ('Ebble_CE1_2013_08_08', 'Ebble_CE1_2013_08_08_ER_Ks_for')
#x1 <- MakeERKsTimeSeries ('Ebble_CE1_2013_04_25', 'Ebble_CE1_2013_04_25_ER_Ks')

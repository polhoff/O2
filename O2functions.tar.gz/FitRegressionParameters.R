

FitRegressionParameters <- function ( c_indata, n_quality = 2 )
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	
	library (parker)
	data (parker)
	
	do.call ( data, list ( c_indata ))
	indata <- get (c_indata)
	
	
	if ( !is.null(indata$qualityFilter))
		{
		indata <- indata[indata$qualityFilter > n_quality,]
		}


	print ( head (indata))
	print ( str (indata))

	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		
		data_sub = indata[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
		
		summary ( data_sub$DO_diff )
		summary ( data_sub$DO_deficit )
		fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_for', sep = ''), x_temp)






































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_mean,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_mean ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_mid', sep = ''), x_temp)

























































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_lag,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_lag ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_lag', sep = ''), x_temp)







	DailyData_ER_Ks <- MakeDailyData(indata)
	


	x_ls <- ls() [grep ( ls(), pattern = '_ER_Ks' )]
	print ( x_ls )

	setwd (dirdmp)
	save (list =  x_ls, file =  paste ( c_indata, '_ER_Ks.rda', sep = ''))
}


#FitRegressionParameters ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParameters ( c_indata = 'Ebble_CE1_2013_08_08' )
























































































































FitRegressionParametersUseLib <- function ( c_indata, c_library, n_quality = 2 )
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	
	library (parker)
	data (parker)
	
	indata <- GetIndata (c_indata, c_library)
	
	
	if ( !is.null(indata$qualityFilter))
		{
		indata <- indata[indata$qualityFilter > n_quality,]
		}


	print ( head (indata))
	print ( str (indata))

	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		
		data_sub = indata[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
		
		summary ( data_sub$DO_diff )
		summary ( data_sub$DO_deficit )
		fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_for', sep = ''), x_temp)






































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_mean,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_mean ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_mid', sep = ''), x_temp)

























































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_lag,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_lag ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_lag', sep = ''), x_temp)





















	x_ls <- ls() [grep ( ls(), pattern = '_ER_Ks' )]
	print ( x_ls )

	setwd (dirdmp)
	save (list =  x_ls, file =  paste ( c_indata, '_ER_Ks.rda', sep = ''))
}


#FitRegressionParameters ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParameters ( c_indata = 'Ebble_CE1_2013_08_08' )







































































































































































































































































































































FitRegressionParametersDataSet <- function ( indata, c_name, n_quality = 2 )
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	#library(mdot)
	library (parker)
	data (parker)
	
	
	
	
	
	if ( !is.null(indata$qualityFilter))
		{
		indata <- indata[indata$qualityFilter > n_quality,]
		}


	print ( head (indata))
	print ( str (indata))

	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		
		data_sub = indata[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
		
		summary ( data_sub$DO_diff )
		summary ( data_sub$DO_deficit )
		fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_name, '_ER_Ks_for', sep = ''), x_temp)






































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_mean,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_mean ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_name, '_ER_Ks_mid', sep = ''), x_temp)

























































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_lag,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_lag ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_name, '_ER_Ks_lag', sep = ''), x_temp)





















	x_ls <- ls() [grep ( ls(), pattern = '_ER_Ks' )]
	print ( x_ls )

	setwd (dirdmp)
	save (list =  x_ls, file =  paste ( c_indata, '_ER_Ks.rda', sep = ''))
}


#FitRegressionParametersDataSet ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParametersDataSet ( c_indata = 'Ebble_CE1_2013_08_08' )




















































































#added temperature as output

FitRegressionParametersDataSet01 <- function ( indata, c_name, which_return )
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	#library(mdot)
	library (parker)
	data (parker)


	print ( head (indata))
	print ( str (indata))

	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 5 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		
		data_sub = indata[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
		
		summary ( data_sub$DO_diff )
		summary ( data_sub$DO_deficit )
		fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		m_coeffs[i,4] <- mean (data_sub$Temp, na.rm = TRUE)
		m_coeffs[i,5] <- median (data_sub$Temp, na.rm = TRUE)
	
		}


	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'mean.Temp','median.Temp')
	assign ( paste (c_name, '_ER_Ks_for', sep = ''), x_temp)

	if(which_return == 1) return_data = x_temp




































	m_coeffs = matrix (nrow = length (x_nights), ncol = 5 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_mean,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_mean ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		m_coeffs[i,4] <- mean (data_sub$Temp, na.rm = TRUE)
		m_coeffs[i,5] <- median (data_sub$Temp, na.rm = TRUE)
	
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'mean.Temp','median.Temp')
	assign ( paste (c_name, '_ER_Ks_mid', sep = ''), x_temp)

	if(which_return == 2) return_data = x_temp























































	m_coeffs = matrix (nrow = length (x_nights), ncol = 5 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_lag,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_lag ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		m_coeffs[i,4] <- mean (data_sub$Temp, na.rm = TRUE)
		m_coeffs[i,5] <- median (data_sub$Temp, na.rm = TRUE)
	
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'mean.Temp','median.Temp')
	assign ( paste (c_name, '_ER_Ks_lag', sep = ''), x_temp)

	if(which_return == 3) return_data = x_temp



















	return (return_data)
	
}


#FitRegressionParametersDataSet01 ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParametersDataSet01 ( c_indata = 'Ebble_CE1_2013_08_08' )
























































































#wrapper

FitRegressionParametersDataSetStd <- function (indata)
	{
	indata <- indata
	outdata <- FitRegressionParametersDataSetStd02(indata)
	return (outdata)
	}









































































































FitRegressionParametersDataSetStd01 <- function (indata)
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	#library(mdot)
	library (parker)
	data (parker)


	indata_sub <- NormalizeIndata(indata)

	x_date = unique ( as.Date (indata_sub$date1))
	

	x_nights = unique ( indata_sub$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 5 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata_sub$daynight1 == x_ndx )
		
		data_sub = indata_sub[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit_mean))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_std,data_sub$DO_deficit_mean)
		
		fit <- try ( lm ( data_sub$DO_diff_std ~ data_sub$DO_deficit_mean ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		m_coeffs[i,4] <- mean (data_sub$Temp, na.rm = TRUE)
		m_coeffs[i,5] <- median (data_sub$Temp, na.rm = TRUE)
	
		}


	#Ebble_CE1_2013_04_25
	outdata <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (outdata) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'mean.Temp','median.Temp')

	return (outdata)
	
}


#FitRegressionParametersDataSetStd ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParametersDataSetStd ( c_indata = 'Ebble_CE1_2013_08_08' )















































































































FitRegressionParametersDataSetStd02 <- function (indata)
	{

	#this differs from FitRegressionParametersDataSetStd01 by cutting of the last hour before dawn
	#and therefore hopefully getting rid of spurious data
	
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	#library(mdot)
	library (parker)
	data (parker)


	indata_sub <- NormalizeIndata(indata)
	
	indata_sub$dawn <- indata_sub$daynight
	dawn_ndx <- with (indata_sub, difftime(Sunrise, date, units = 'mins'))
	dawn_ndx <- dawn_ndx <= 0 & dawn_ndx > -60
	indata_sub$dawn[dawn_ndx] <- 'dawn'


	x_date = unique ( as.Date (indata_sub$date1))
	

	x_nights = unique ( indata_sub$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 5 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata_sub$daynight1 == x_ndx )
		
		data_sub = indata_sub[data_sub_ndx, ]
		#exclude dawn
		data_sub = data_sub[data_sub$dawn != 'dawn',]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit_mean))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_std,data_sub$DO_deficit_mean)
		
		fit <- try ( lm ( data_sub$DO_diff_std ~ data_sub$DO_deficit_mean ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		m_coeffs[i,4] <- mean (data_sub$Temp, na.rm = TRUE)
		m_coeffs[i,5] <- median (data_sub$Temp, na.rm = TRUE)
	
		}


	#Ebble_CE1_2013_04_25
	outdata <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (outdata) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'mean.Temp','median.Temp')

	return (outdata)
	
}


#FitRegressionParametersDataSetStd ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParametersDataSetStd ( c_indata = 'Ebble_CE1_2013_08_08' )






























































































































































































































































































































































































































































































FitRegressionParametersIterate <- function ( c_dataset, c_library, c_name, n_limit = 0.007, n_quality = 2, metric_type = 1 )
	{
	#indata <- Ebble_CE1_2013_04_25
	#c_library <- mdot
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'
	

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	#library(mdot)
	library (parker)
	data (parker)
	
	do.call ( library, list (c_library))
	
	DataSets <- parker::ListData (c_library)
	rownumber <- which (DataSets[,1] == c_dataset)
	
	#return (rownumber)
	indata <- parker::LoadData (c_library, rownumber)

	
	if ( !is.null(indata$qualityFilter))
		{
		indata <- indata[indata$qualityFilter > n_quality,]
		}

	print ( str (indata))
	print ( head (indata,2))
	
	#plot (indata$date, indata$DO) 


	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	

	m_coeffs = matrix (nrow = length (x_nights), ncol = 4 )

		for ( i in 1:length (x_nights) )
		#for ( i in 1:10 )
			{
			
			#i = 1
			x_ndx = x_nights[i]
			
			data_sub_ndx = which ( indata$daynight1 == x_ndx )
			
			data_sub = indata[data_sub_ndx, ]
			
			x_ndx1 = which ( !is.na (data_sub$DO_deficit))
			
			data_sub = data_sub[x_ndx1, ]
			
			
			x_ndx2 <- x_ndx1
			l_test <- TRUE
			while (l_test)
				{
				data_sub <- data_sub[x_ndx2,]
				#with ( data_sub, plot ( DO_deficit, DO_change ))
				n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
				
				summary ( data_sub$DO_diff )
				summary ( data_sub$DO_deficit )
				fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))
				
				n_fitted <- fitted.values (fit)
				#x_fit <- predict (fit, data_sub$DO_deficit)
				n_res <- residuals(fit)
				n_res_proportion <- (as.numeric (n_res) - as.numeric(n_fitted)) / as.numeric(n_fitted)
				print (n_res_proportion)
				print (summary (n_res_proportion))
				
				#Wait()
				plot (data_sub$DO_deficit, data_sub$DO_diff)
				points (data_sub$DO_deficit, n_fitted, col = 'red')
				
				#print (n_res)
				#print (n_res_proportion)
				
				if (metric_type == 1) {x_ndx2 <- (abs (n_res) < n_limit)}
				if (metric_type == 2) {x_ndx2 <- (abs (n_res_proportion) < n_limit)}
				print (FALSE %in% x_ndx2)
				
				Wait()
				plot (data_sub$DO_deficit, data_sub$DO_diff)
				if ( !(FALSE %in% x_ndx2)) l_test <- FALSE
				}
			
			plot (data_sub$DO_deficit, data_sub$DO_diff, col = 'green')
			points (data_sub$DO_deficit, n_fitted, col = 'red')
			Wait(0.2)
			
			n_inter <-  as.numeric (fit[[1]][1])
			n_slope <-  as.numeric (fit[[1]][2])


			m_coeffs[i,1] <- n_inter
			m_coeffs[i,2] <- n_slope
			m_coeffs[i,3] <- n_cor
			m_coeffs[i,4] <- dim(data_sub)[1]
			}

	DailyData <- MakeDailyData(indata)
	#DailyData <- MakeDailyData(indata)

	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'N')
	x_temp <- merge (x_temp, DailyData, by = 'date1')
	assign ( paste (c_dataset, '_ER_Ks', n_limit, sep = ''), x_temp)


	x_ls <- ls() [grep ( ls(), pattern = '_ER_Ks' )]
	print ( x_ls )

	setwd (dirdmp)
	save (list =  x_ls, file =  paste ( c_dataset, '_ER_Ks', n_limit,'.rda', sep = ''))

	#return (n_res_proportion)
	return (x_temp)
	}



#FitRegressionParametersIterate ( c_dataset = 'Nadder_GN1_2014-08-20_md', c_library = 'mdot.data')
#FitRegressionParametersIterate ( c_dataset = 'Nadder_GN1_2014-08-20_md', c_library = 'mdot.data', n_limit = 0.007)
#FitRegressionParametersIterate ( c_dataset = 'Nadder_GN1_2014-08-20_md', c_library = 'mdot.data', n_limit = 20, metric_type = 2)
#regressed <- FitRegressionParametersIterate ( c_dataset = 'Nadder_GN1_2014-08-20_md', c_library = 'mdot.data', n_limit = 0.007, metric_type = 1)



#regressed01 <- FitRegressionParametersIterate ( c_dataset = 'Ebble_CE1_2014-08-21_md', c_library = 'mdot.data', n_limit = 0.007, metric_type = 1)
#regressed02 <- FitRegressionParametersIterate ( c_dataset = 'Ebble_CE1_2014-08-21_md', c_library = 'mdot.data', n_limit = 5, metric_type = 1)
#regressed03 <- FitRegressionParametersIterate ( c_dataset = 'Ebble_CE1_2014-08-21_md', c_library = 'mdot.data', n_limit = 50, metric_type = 2)


#regressed01 <- regressed01[1:41,]
#regressed02 <- regressed02[1:41,]
#regressed03 <- regressed03[1:41,]

#with (regressed01, plot ( date1, ER, type = 'b', ylim = c (-0.02, -0.00)))
#with (regressed02, points ( date1, ER, type = 'b', col = 'red'))
#with (regressed03, points ( date1, ER, type = 'b', col = 'blue'))

































































































































































































FitRegressionParametersSingleDF <- function ( c_indata, n_quality = 2 )
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	
	library (parker)
	data (parker)
	
	do.call ( data, list ( c_indata ))
	indata <- get (c_indata)
	
	
	if ( !is.null(indata$qualityFilter))
		{
		indata <- indata[indata$qualityFilter > n_quality,]
		}


	print ( head (indata))
	print ( str (indata))

	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		
		data_sub = indata[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
		
		summary ( data_sub$DO_diff )
		summary ( data_sub$DO_deficit )
		fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_for', sep = ''), x_temp)






































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_mean,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_mean ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_mid', sep = ''), x_temp)

























































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_lag,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_lag ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_lag', sep = ''), x_temp)





















	x_ls <- ls() [grep ( ls(), pattern = '_ER_Ks' )]
	print ( x_ls )

	setwd (dirdmp)
	save (list =  x_ls, file =  paste ( c_indata, '_ER_Ks.rda', sep = ''))
}


#FitRegressionParametersSingleDF ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParametersSingleDF ( c_indata = 'Ebble_CE1_2013_08_08' )










































































































































































































FitRegressionParametersModelled <- function (indata)
	{
	#indata <- Ebble_CE1_2013_04_25
	#library (mdot); data (Minidot_02); indata <- Minidot_02; n_quality = 14; c_indata <- 'Minidot_02'

	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')
	
	#library(mdot)
	library (parker)
	data (parker)

	indata <- ProcessReAerOutput (indata)

	x_date = unique ( as.Date (indata$date1))
	

	x_nights = unique ( indata_sub$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 5 )

	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata_sub$daynight1 == x_ndx )
		
		data_sub = indata_sub[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit_mean))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_std,data_sub$DO_deficit_mean)
		
		fit <- try ( lm ( data_sub$DO_diff_std ~ data_sub$DO_deficit_mean ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		m_coeffs[i,4] <- mean (data_sub$Temp, na.rm = TRUE)
		m_coeffs[i,5] <- median (data_sub$Temp, na.rm = TRUE)
	
		}


	#Ebble_CE1_2013_04_25
	outdata <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (outdata) <- c ('date1', 'daynight1','ER','Ks', 'correlation', 'mean.Temp','median.Temp')

	return (outdata)
	
}


#FitRegressionParametersDataSetStd ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParametersDataSetStd ( c_indata = 'Ebble_CE1_2013_08_08' )





















































































FitRegressionParameters_v01 <- function ( c_indata )
	{
	#indata <- Ebble_CE1_2013_04_25
	#dirscr <- paste ( dirtop, '/DO/rovscript/', sep = '')

	library (parker)
	data (parker)
	
	do.call ( data, list ( c_indata ))
	indata <- get (c_indata)

	print ( head (indata))
	print ( str (indata))

	#max_y <- max ( indata$Cnow, indata$DO, na.rm = T )
	#min_y <- min ( indata$Cnow, indata$DO, na.rm = T )


	x_date = unique ( as.Date (indata$date1))

	

	x_nights = unique ( indata$daynight1 )
	x_nights = x_nights[grep ('night', x_nights)]
	
	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )
	

	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		
		data_sub = indata[data_sub_ndx, ]
		
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff,data_sub$DO_deficit)
		
		summary ( data_sub$DO_diff )
		summary ( data_sub$DO_deficit )
		fit <- try ( lm ( data_sub$DO_diff ~ data_sub$DO_deficit ))

		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}

	#Ebble_CE1_2013_04_25
	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_for', sep = ''), x_temp)






































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_mean,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_mean ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_mid', sep = ''), x_temp)

























































	m_coeffs = matrix (nrow = length (x_nights), ncol = 3 )


	for ( i in 1:length (x_nights) )
		{
		
		#i = 1
		x_ndx = x_nights[i]
		data_sub_ndx = which ( indata$daynight1 == x_ndx )
		data_sub = indata[data_sub_ndx, ]
		x_ndx1 = which ( !is.na (data_sub$DO_deficit))
		data_sub = data_sub[x_ndx1, ]
		
		#with ( data_sub, plot ( DO_deficit, DO_change ))
		n_cor <- cor(data_sub$DO_diff_lag,data_sub$DO_deficit)
		fit <- try ( lm ( data_sub$DO_diff_lag ~ data_sub$DO_deficit ))

		
		n_inter <-  as.numeric (fit[[1]][1])
		n_slope <-  as.numeric (fit[[1]][2])


		m_coeffs[i,1] <- n_inter
		m_coeffs[i,2] <- n_slope
		m_coeffs[i,3] <- n_cor
		}


	x_temp <- data.frame ( x_date[1:length (x_nights)], x_nights, m_coeffs )
	names (x_temp) <- c ('date1', 'daynight1','ER','Ks', 'correlation')
	assign ( paste (c_indata, '_ER_Ks_lag', sep = ''), x_temp)










	x_ls <- ls() [grep ( ls(), pattern = '_ER_Ks' )]
	print ( x_ls )

	setwd (dirdmp)
	save (list =  x_ls, file =  paste ( c_indata, '_ER_Ks.rda', sep = ''))
}


#FitRegressionParameters ( c_indata = 'Ebble_CE1_2013_04_25' )
#FitRegressionParameters ( c_indata = 'Ebble_CE1_2013_08_08' )





































































NormalizeIndata <- function(indata)
	{
	
	DO_diff_std <- embed (indata$DO,2)
	DO_diff_std <- DO_diff_std[,1] - DO_diff_std[,2]
	
	
	CSat_diff_std <- embed (indata$CSat,2)
	CSat_diff_std <- CSat_diff_std[,1] - CSat_diff_std[,2]
	

	time_diff <- embed (as.ts(indata[,c('date')]),2)
	#gives time difference in seconds
	time_diff <- time_diff[,1] - time_diff[,2]
	time_diff <- time_diff / 60
	#gives time difference in minutes
	indata$time_diff <- c(NA, time_diff)

	#standardize DO change over the time interval
	indata$DO_diff_std <- c (NA, DO_diff_std / time_diff)
	indata$CSat_diff_std <- c (NA, CSat_diff_std / time_diff)

	
	indata$DO_deficit_mean <- c(NA, rowMeans(embed(indata$CSat - indata$DO, 2)))
	indata$Temp_mean <- c(NA, rowMeans(embed(indata$Temp, 2)))

	return(indata)
	}
	
#x <- NormalizeIndata(indata); head(x)




#ER is already negative as a result of the correlation (intercept on y axis
Resp2 <- function ( ER )
	{
	x <- ER
	}

